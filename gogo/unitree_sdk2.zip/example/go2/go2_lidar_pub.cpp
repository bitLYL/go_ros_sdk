#include <unitree/robot/channel/channel_subscriber.hpp>
#include <unitree/common/time/time_tool.hpp>
#include <unitree/idl/ros2/PointCloud2_.hpp>
#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>

#define TOPIC_CLOUD "rt/utlidar/cloud"

using namespace unitree::robot;
using namespace unitree::common;

ros::Publisher cloud_pub;

void Handler(const void *message)
{
    const sensor_msgs::msg::dds_::PointCloud2_ *cloud_msg_dds = (const sensor_msgs::msg::dds_::PointCloud2_ *)message;

    // 创建ROS 1的PointCloud2消息
    sensor_msgs::PointCloud2 cloud_msg_ros;
    cloud_msg_ros.header.stamp = ros::Time(cloud_msg_dds->header().stamp().sec(), cloud_msg_dds->header().stamp().nanosec());
    cloud_msg_ros.header.frame_id = cloud_msg_dds->header().frame_id();
    cloud_msg_ros.height = cloud_msg_dds->height();
    cloud_msg_ros.width = cloud_msg_dds->width();
    cloud_msg_ros.fields.resize(cloud_msg_dds->fields().size());
    for (size_t i = 0; i < cloud_msg_dds->fields().size(); ++i)
    {
        cloud_msg_ros.fields[i].name = cloud_msg_dds->fields()[i].name();
        cloud_msg_ros.fields[i].offset = cloud_msg_dds->fields()[i].offset();
        cloud_msg_ros.fields[i].datatype = cloud_msg_dds->fields()[i].datatype();
        cloud_msg_ros.fields[i].count = cloud_msg_dds->fields()[i].count();
    }
    cloud_msg_ros.is_bigendian = cloud_msg_dds->is_bigendian();
    cloud_msg_ros.point_step = cloud_msg_dds->point_step();
    cloud_msg_ros.row_step = cloud_msg_dds->row_step();
    cloud_msg_ros.data.resize(cloud_msg_dds->data().size());
    std::copy(cloud_msg_dds->data().begin(), cloud_msg_dds->data().end(), cloud_msg_ros.data.begin());
    cloud_msg_ros.is_dense = cloud_msg_dds->is_dense();

    // 发布ROS 1的PointCloud2消息
    cloud_pub.publish(cloud_msg_ros);

    std::cout << "Received a raw cloud here!"
              << "\n\tstamp = " << cloud_msg_dds->header().stamp().sec() << "." << cloud_msg_dds->header().stamp().nanosec()
              << "\n\tframe = " << cloud_msg_dds->header().frame_id()
              << "\n\tpoints number = " << cloud_msg_dds->width()
              << std::endl
              << std::endl;
}

int main(int argc, const char **argv)
{
    if (argc < 2)
    {
        std::cout << "Usage: " << argv[0] << " networkInterface" << std::endl;
        exit(-1);
    }

    // 初始化ROS节点
    ros::init(argc, const_cast<char **>(argv), "cloud_publisher");
    ros::NodeHandle nh;

    // 创建点云发布者
    cloud_pub = nh.advertise<sensor_msgs::PointCloud2>("cloud_data", 10);

    ChannelFactory::Instance()->Init(0, argv[1]);

    ChannelSubscriber<sensor_msgs::msg::dds_::PointCloud2_> subscriber(TOPIC_CLOUD);
    subscriber.InitChannel(Handler);

    ros::Rate rate(50); // 50Hz
    while (ros::ok())
    {
        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}

