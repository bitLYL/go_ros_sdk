/**
 * @file publish_pointcloud_ros1.cpp
 * @brief Subscribe deskewed pointcloud from Unitree DDS and publish as ROS1 PointCloud2
 * @date 2025-05-30
 */

#include <unitree/robot/channel/channel_subscriber.hpp>
#include <unitree/common/time/time_tool.hpp>
#include <unitree/idl/ros2/PointCloud2_.hpp>

#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>

#define TOPIC_CLOUD "rt/utlidar/cloud_deskewed"

using namespace unitree::robot;
using namespace unitree::common;

ros::Publisher cloud_pub;

void Handler(const void *message)
{
    const auto *cloud_msg_dds = static_cast<const sensor_msgs::msg::dds_::PointCloud2_ *>(message);

    // 使用 DDS 消息中的原始时间戳
    ros::Time stamp(cloud_msg_dds->header().stamp().sec(), cloud_msg_dds->header().stamp().nanosec());

    // 构造 ROS1 点云消息
    sensor_msgs::PointCloud2 cloud_msg_ros;
    cloud_msg_ros.header.stamp = stamp;
    cloud_msg_ros.header.frame_id = "base_link";  // 建议使用odom坐标系，兼容性好

    cloud_msg_ros.height = cloud_msg_dds->height();
    cloud_msg_ros.width = cloud_msg_dds->width();

    // 拷贝字段结构
    const auto &fields_dds = cloud_msg_dds->fields();
    cloud_msg_ros.fields.resize(fields_dds.size());
    for (size_t i = 0; i < fields_dds.size(); ++i)
    {
        cloud_msg_ros.fields[i].name = fields_dds[i].name();
        cloud_msg_ros.fields[i].offset = fields_dds[i].offset();
        cloud_msg_ros.fields[i].datatype = fields_dds[i].datatype();
        cloud_msg_ros.fields[i].count = fields_dds[i].count();
    }

    // 设置其他元信息
    cloud_msg_ros.is_bigendian = cloud_msg_dds->is_bigendian();
    cloud_msg_ros.point_step = cloud_msg_dds->point_step();
    cloud_msg_ros.row_step = cloud_msg_dds->row_step();
    cloud_msg_ros.is_dense = cloud_msg_dds->is_dense();

    // 拷贝数据内容
    const auto &data_dds = cloud_msg_dds->data();
    cloud_msg_ros.data.resize(data_dds.size());
    std::copy(data_dds.begin(), data_dds.end(), cloud_msg_ros.data.begin());

    // 发布点云
    cloud_pub.publish(cloud_msg_ros);

    // 可选调试输出
    ROS_INFO_STREAM_ONCE("[INFO] First deskewed cloud received:"
                         << "\n  - stamp = " << stamp
                         << "\n  - frame_id = " << cloud_msg_ros.header.frame_id
                         << "\n  - width = " << cloud_msg_ros.width
                         << "\n  - height = " << cloud_msg_ros.height
                         << "\n  - fields = " << fields_dds.size()
                         << "\n  - point_step = " << cloud_msg_ros.point_step
                         << "\n  - row_step = " << cloud_msg_ros.row_step
                         << "\n  - is_dense = " << (cloud_msg_ros.is_dense ? "true" : "false"));
}

int main(int argc, const char **argv)
{
    if (argc < 2)
    {
        std::cerr << "Usage: " << argv[0] << " networkInterface" << std::endl;
        return -1;
    }

    // 初始化 ROS 节点
    ros::init(argc, const_cast<char **>(argv), "cloud_deskewed_publisher");
    ros::NodeHandle nh;

    cloud_pub = nh.advertise<sensor_msgs::PointCloud2>("cloud_deskewed", 10);

    // 初始化 DDS 通道
    ChannelFactory::Instance()->Init(0, argv[1]);

    ChannelSubscriber<sensor_msgs::msg::dds_::PointCloud2_> subscriber(TOPIC_CLOUD);
    subscriber.InitChannel(Handler);

    // 循环保持高频处理，避免积压丢包
    ros::Rate rate(100);
    while (ros::ok())
    {
        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}
