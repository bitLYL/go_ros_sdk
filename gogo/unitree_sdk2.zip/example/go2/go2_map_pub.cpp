/**
 * @file subscribe_height_map.cpp
 * @brief Subscribe the height map published from DDS topic
 * @date 2023-11-23
 */

#include <unitree/robot/channel/channel_subscriber.hpp>
#include <unitree/common/time/time_tool.hpp>
#include <unitree/idl/go2/HeightMap_.hpp>

#define TOPIC_HEIGHTMAP "rt/utlidar/height_map_array"

using namespace unitree::robot;
using namespace unitree::common;

void Handler(const void *message)
{
  // print msg info
  const unitree_go::msg::dds_::HeightMap_ *map_msg = (const unitree_go::msg::dds_::HeightMap_ *)message;
  std::cout << "Received a height map here!"
            << std::setprecision(14)
            << "\n\tstamp = " << map_msg->stamp()
            << "\n\tframe = " << map_msg->frame_id()
            << "\n\twidth = " << map_msg->width()
            << "\n\theight = " << map_msg->height()
            << "\n\tresolution = " << map_msg->resolution()
            << std::endl << std::endl;
  
  // Parse a height map to a pointcloud in world frame
  std::vector<std::array<float, 3>> cloud; // the element of std::array is x, y and z respectively
  int width = map_msg->width();
  int height = map_msg->height();
  float resolution = map_msg->resolution();
  float originX = map_msg->origin()[0];
  float originY = map_msg->origin()[1];
  
  int index;
  std::array<float, 3> pt;
  for (int iy = 0; iy< height; iy++){
    for (int ix = 0; ix< width; ix++){
      index = ix + width * iy;
      pt[2] = map_msg->data()[index];
      if (pt[2] == 1.0e9) { // skip empty cell value which is set to 1.0e9
        continue;
      }
      pt[0] = ix * resolution + originX;
      pt[1] = iy * resolution + originY;
      cloud.push_back(pt);
    }
  }
}

int main(int argc, const char **argv)
{
  if (argc < 2)
  {
    std::cout << "Usage: " << argv[0] << " networkInterface" << std::endl;
    exit(-1);
  }

  ChannelFactory::Instance()->Init(0, argv[1]);

  ChannelSubscriber<unitree_go::msg::dds_::HeightMap_> subscriber(TOPIC_HEIGHTMAP);
  subscriber.InitChannel(Handler);

  while (true)
  {
    sleep(10);
  }

  return 0;
}
