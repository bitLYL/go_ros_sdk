#include <ros/ros.h>
#include <geometry_msgs/PointStamped.h>

#include <unitree/robot/channel/channel_subscriber.hpp>
#include <unitree/common/time/time_tool.hpp>
#include <unitree/idl/ros2/PointStamped_.hpp>

#define TOPIC_RANGE_INFO "rt/utlidar/range_info"

using namespace unitree::robot;
using namespace unitree::common;

// 全局 ROS 发布器
ros::Publisher range_pub;

void Handler(const void *message)
{
  const geometry_msgs::msg::dds_::PointStamped_ *range_msg = (const geometry_msgs::msg::dds_::PointStamped_ *)message;

  std::cout << "Received a range info message here!"
            << "\n\tstamp = " << range_msg->header().stamp().sec() << "." << range_msg->header().stamp().nanosec()
            << "\n\tframe = " << range_msg->header().frame_id()
            << "\n\trange front = " << range_msg->point().x()
            << "\n\trange left = " << range_msg->point().y()
            << "\n\trange right = " << range_msg->point().z()
            << std::endl << std::endl;

  // 构造 ROS1 PointStamped 消息
  geometry_msgs::PointStamped ros_msg;
  ros_msg.header.stamp = ros::Time::now(); // 或者从 range_msg 时间戳转换（如需同步）
  ros_msg.header.frame_id = "base";        // 可根据实际需要替换为 range_msg->header().frame_id()
  ros_msg.point.x = range_msg->point().x();
  ros_msg.point.y = range_msg->point().y();
  ros_msg.point.z = range_msg->point().z();

  // 发布 ROS 话题
  range_pub.publish(ros_msg);
}

int main(int argc, char **argv)
{
  if (argc < 2)
  {
    std::cout << "Usage: " << argv[0] << " <network_interface>" << std::endl;
    return -1;
  }

  ros::init(argc, argv, "subscribe_range_info");
  ros::NodeHandle nh;
  range_pub = nh.advertise<geometry_msgs::PointStamped>("/range_info", 10);

  // 初始化 DDS 订阅
  ChannelFactory::Instance()->Init(0, argv[1]);
  ChannelSubscriber<geometry_msgs::msg::dds_::PointStamped_> subscriber(TOPIC_RANGE_INFO);
  subscriber.InitChannel(Handler);

  ros::spin(); // 进入 ROS 回调循环

  return 0;
}
