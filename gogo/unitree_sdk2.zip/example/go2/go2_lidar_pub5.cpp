/**
 * @file subscribe_pointcloud.cpp
 * @brief Subscribe the pointcloud published from DDS topic
 * @date 2023-11-23
 */

#include <unitree/robot/channel/channel_subscriber.hpp>
#include <unitree/common/time/time_tool.hpp>
#include <unitree/idl/ros2/PointCloud2_.hpp>

#include <iostream>
#include <atomic>
#include <thread>

#define TOPIC_CLOUD "rt/utlidar/cloud_deskewed"

using namespace unitree::robot;
using namespace unitree::common;

std::atomic<int> messageCount(0);
std::atomic<bool> running(true);

void Handler(const void *message)
{
  const sensor_msgs::msg::dds_::PointCloud2_ *cloud_msg = (const sensor_msgs::msg::dds_::PointCloud2_ *)message;
  std::cout << "[" << messageCount++ << "] Received a raw cloud here!"
            << "\n\tstamp = " << cloud_msg->header().stamp().sec() << "." << cloud_msg->header().stamp().nanosec()
            << "\n\tframe = " << cloud_msg->header().frame_id()
            << "\n\tpoints number = " << cloud_msg->width()
            << std::endl
            << std::endl;
}

int main(int argc, const char **argv)
{
  if (argc < 2)
  {
    std::cout << "Usage: " << argv[0] << " networkInterface" << std::endl;
    exit(-1);
  }

  ChannelFactory::Instance()->Init(0, argv[1]);

  ChannelSubscriber<sensor_msgs::msg::dds_::PointCloud2_> subscriber(TOPIC_CLOUD);
  subscriber.InitChannel(Handler);

  // 显示初始化完成
  std::cout << "PointCloud subscriber initialized on interface: " << argv[1] << std::endl;
  std::cout << "Waiting for data on topic: " << TOPIC_CLOUD << std::endl;
  
  // 使用更短的休眠时间或其他等待机制
  while (running)
  {
    // 每100毫秒检查一次是否有退出信号
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
  }

  std::cout << "Shutting down..." << std::endl;
  return 0;
}

