#include <unitree/idl/go2/SportModeState_.hpp>
#include <unitree/robot/channel/channel_subscriber.hpp>
#include <ros/ros.h>
#include <sensor_msgs/Imu.h>

//高层状态topic，其中rt表示实时，lf表示低频
#define TOPIC_HIGHSTATE "rt/sportmodestate"

using namespace unitree::robot;

ros::Publisher imu_pub;

//获取运动状态的回调函数
void HighStateHandler(const void* message)
{
    unitree_go::msg::dds_::SportModeState_ state = *(unitree_go::msg::dds_::SportModeState_*)message;

    // 创建IMU消息
    sensor_msgs::Imu imu_msg;
    imu_msg.header.stamp = ros::Time::now();
    imu_msg.header.frame_id = "imu_link";

    // 设置姿态四元数
    imu_msg.orientation.w = state.imu_state().quaternion()[0];
    imu_msg.orientation.x = state.imu_state().quaternion()[1];
    imu_msg.orientation.y = state.imu_state().quaternion()[2];
    imu_msg.orientation.z = state.imu_state().quaternion()[3];

    // 设置角速度
    imu_msg.angular_velocity.x = state.imu_state().gyroscope()[0];
    imu_msg.angular_velocity.y = state.imu_state().gyroscope()[1];
    imu_msg.angular_velocity.z = state.imu_state().gyroscope()[2];

    // 设置线加速度
    imu_msg.linear_acceleration.x = state.imu_state().accelerometer()[0];
    imu_msg.linear_acceleration.y = state.imu_state().accelerometer()[1];
    imu_msg.linear_acceleration.z = state.imu_state().accelerometer()[2];

    // 发布IMU消息
    imu_pub.publish(imu_msg);

    //打印输出机器狗位置
    std::cout << "position: "
              << state.position()[0] << ", "
              << state.position()[1] << ", "
              << state.position()[2] << std::endl;
    //打印输出机器狗姿态四元数 (w,x,y,z)
    std::cout << "quaternion: "
              << state.imu_state().quaternion()[0] << ", "
              << state.imu_state().quaternion()[1] << ", "
              << state.imu_state().quaternion()[2] << ", "
              << state.imu_state().quaternion()[3] << std::endl;
    // 打印输出角速度
    std::cout << "gyroscope: "
              << state.imu_state().gyroscope()[0] << ", "
              << state.imu_state().gyroscope()[1] << ", "
              << state.imu_state().gyroscope()[2] << std::endl;
    // 打印输出线加速度
    std::cout << "accelerometer: "
              << state.imu_state().accelerometer()[0] << ", "
              << state.imu_state().accelerometer()[1] << ", "
              << state.imu_state().accelerometer()[2] << std::endl;
    // 打印输出欧拉角
    std::cout << "rpy: "
              << state.imu_state().rpy()[0] << ", "
              << state.imu_state().rpy()[1] << ", "
              << state.imu_state().rpy()[2] << std::endl;
}


int main(int argc, char **argv)
{
    // 初始化ROS节点
    ros::init(argc, argv, "imu_publisher");
    ros::NodeHandle nh;

    // 创建IMU发布者
    imu_pub = nh.advertise<sensor_msgs::Imu>("imu_data", 10);

    //初始化sdk接口
    std::string networkInterface = "eth1";//机器人连接的网卡名称
    unitree::robot::ChannelFactory::Instance()->Init(0, networkInterface);

    //创建一个Subscriber
    ChannelSubscriber<unitree_go::msg::dds_::SportModeState_> suber(TOPIC_HIGHSTATE);

    //初始化Channel
    suber.InitChannel(HighStateHandler);

    ros::Rate rate(50); // 50Hz
    while (ros::ok())
    {
        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}
