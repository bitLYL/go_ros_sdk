#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/point_cloud2_iterator.h>

#include <unitree/robot/channel/channel_subscriber.hpp>
#include <unitree/common/time/time_tool.hpp>
#include <unitree/idl/go2/HeightMap_.hpp>

#include <iostream>
#include <iomanip>
#include <vector>
#include <array>

#define TOPIC_HEIGHTMAP "rt/utlidar/height_map_array"

using namespace unitree::robot;
using namespace unitree::common;

// 全局 ROS 发布器
ros::Publisher pc_pub;

void Handler(const void *message)
{
  const unitree_go::msg::dds_::HeightMap_ *map_msg = (const unitree_go::msg::dds_::HeightMap_ *)message;

  std::cout << "Received a height map!"
            << std::setprecision(14)
            << "\n\tstamp = " << map_msg->stamp()
            << "\n\tframe = " << map_msg->frame_id()
            << "\n\twidth = " << map_msg->width()
            << "\n\theight = " << map_msg->height()
            << "\n\tresolution = " << map_msg->resolution()
            << std::endl << std::endl;

  // 解析高度图为点云
  std::vector<std::array<float, 3>> cloud;
  int width = map_msg->width();
  int height = map_msg->height();
  float resolution = map_msg->resolution();
  float originX = map_msg->origin()[0];
  float originY = map_msg->origin()[1];

  int index;
  std::array<float, 3> pt;
  for (int iy = 0; iy < height; iy++)
  {
    for (int ix = 0; ix < width; ix++)
    {
      index = ix + width * iy;
      pt[2] = map_msg->data()[index];
      if (pt[2] == 1.0e9) // 空值，跳过
        continue;
      pt[0] = ix * resolution + originX;
      pt[1] = iy * resolution + originY;
      cloud.push_back(pt);
    }
  }

  // 构造 ROS PointCloud2 消息
  sensor_msgs::PointCloud2 cloud_msg;
  cloud_msg.header.stamp = ros::Time::now();
  cloud_msg.header.frame_id = "map"; // 可改为 "map" 或 "odom"
  cloud_msg.height = 1;
  cloud_msg.width = cloud.size();
  cloud_msg.is_dense = false;
  cloud_msg.is_bigendian = false;

  sensor_msgs::PointCloud2Modifier modifier(cloud_msg);
  modifier.setPointCloud2FieldsByString(1, "xyz");
  modifier.resize(cloud.size());

  sensor_msgs::PointCloud2Iterator<float> iter_x(cloud_msg, "x");
  sensor_msgs::PointCloud2Iterator<float> iter_y(cloud_msg, "y");
  sensor_msgs::PointCloud2Iterator<float> iter_z(cloud_msg, "z");

  for (const auto& pt : cloud)
  {
    *iter_x = pt[0];
    *iter_y = pt[1];
    *iter_z = pt[2];
    ++iter_x;
    ++iter_y;
    ++iter_z;
  }

  pc_pub.publish(cloud_msg);
}

int main(int argc, char **argv)
{
  if (argc < 2)
  {
    std::cout << "Usage: " << argv[0] << " <network_interface>" << std::endl;
    return -1;
  }

  ros::init(argc, argv, "subscribe_height_map");
  ros::NodeHandle nh;
  pc_pub = nh.advertise<sensor_msgs::PointCloud2>("/unitree/heightmap_pc", 1);

  ChannelFactory::Instance()->Init(0, argv[1]);

  ChannelSubscriber<unitree_go::msg::dds_::HeightMap_> subscriber(TOPIC_HEIGHTMAP);
  subscriber.InitChannel(Handler);

  ros::spin(); // 进入 ROS 回调循环

  return 0;
}
