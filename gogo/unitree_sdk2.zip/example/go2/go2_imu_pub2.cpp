/**
 * @file imu_state_publisher.cpp
 * @brief Subscribe SportModeState from Unitree DDS and publish as ROS1 Imu + Position messages
 * @date 2025-05-27
 */

#include <unitree/idl/go2/SportModeState_.hpp>
#include <unitree/robot/channel/channel_subscriber.hpp>
#include <ros/ros.h>
#include <sensor_msgs/Imu.h>
#include <geometry_msgs/PointStamped.h>

#define TOPIC_HIGHSTATE "rt/sportmodestate"

using namespace unitree::robot;

ros::Publisher imu_pub;
ros::Publisher position_pub;

void HighStateHandler(const void* message)
{
    const auto& state = *(const unitree_go::msg::dds_::SportModeState_*)message;

    ros::Time now = ros::Time::now();  // 统一时间戳

    // 创建并填充 IMU 消息
    sensor_msgs::Imu imu_msg;
    imu_msg.header.stamp = now;
    imu_msg.header.frame_id = "imu_link";

    // 姿态四元数
    imu_msg.orientation.w = state.imu_state().quaternion()[0];
    imu_msg.orientation.x = state.imu_state().quaternion()[1];
    imu_msg.orientation.y = state.imu_state().quaternion()[2];
    imu_msg.orientation.z = state.imu_state().quaternion()[3];

    // 角速度
    imu_msg.angular_velocity.x = state.imu_state().gyroscope()[0];
    imu_msg.angular_velocity.y = state.imu_state().gyroscope()[1];
    imu_msg.angular_velocity.z = state.imu_state().gyroscope()[2];

    // 线加速度
    imu_msg.linear_acceleration.x = state.imu_state().accelerometer()[0];
    imu_msg.linear_acceleration.y = state.imu_state().accelerometer()[1];
    imu_msg.linear_acceleration.z = state.imu_state().accelerometer()[2];

    // 设置协方差：-1 表示未知（下游节点会按默认方式处理）
    for (int i = 0; i < 9; ++i)
    {
        imu_msg.orientation_covariance[i] = -1;
        imu_msg.angular_velocity_covariance[i] = -1;
        imu_msg.linear_acceleration_covariance[i] = -1;
    }

    imu_pub.publish(imu_msg);

    // 创建并发布位置消息
    geometry_msgs::PointStamped position_msg;
    position_msg.header.stamp = now;
    position_msg.header.frame_id = "map";
    position_msg.point.x = state.position()[0];
    position_msg.point.y = state.position()[1];
    position_msg.point.z = state.position()[2];

    position_pub.publish(position_msg);

    // 打印调试信息
    std::cout << "\n[INFO] Robot State:"
              << "\n  Position      = (" << state.position()[0] << ", " << state.position()[1] << ", " << state.position()[2] << ")"
              << "\n  Orientation   = (" << imu_msg.orientation.w << ", "
              << imu_msg.orientation.x << ", " << imu_msg.orientation.y << ", " << imu_msg.orientation.z << ")"
              << "\n  Gyroscope     = (" << imu_msg.angular_velocity.x << ", "
              << imu_msg.angular_velocity.y << ", " << imu_msg.angular_velocity.z << ")"
              << "\n  Accelerometer = (" << imu_msg.linear_acceleration.x << ", "
              << imu_msg.linear_acceleration.y << ", " << imu_msg.linear_acceleration.z << ")"
              << "\n  RPY (Euler)   = (" << state.imu_state().rpy()[0] << ", "
              << state.imu_state().rpy()[1] << ", " << state.imu_state().rpy()[2] << ")"
              << std::endl;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "imu_publisher");
    ros::NodeHandle nh;

    imu_pub = nh.advertise<sensor_msgs::Imu>("imu_data", 10);
    position_pub = nh.advertise<geometry_msgs::PointStamped>("robot_position", 10);

    std::string networkInterface = "eth0";  // 替换为实际网卡名
    ChannelFactory::Instance()->Init(0, networkInterface);

    ChannelSubscriber<unitree_go::msg::dds_::SportModeState_> subscriber(TOPIC_HIGHSTATE);
    subscriber.InitChannel(HighStateHandler);

    ros::Rate rate(50);
    while (ros::ok())
    {
        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}
