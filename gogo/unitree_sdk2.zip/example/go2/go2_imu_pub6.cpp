/**
 * @file imu_state_tf_publisher.cpp
 * @brief Subscribe SportModeState from Unitree DDS and publish IMU + Pose + TF as ROS1 messages
 * @date 2025-05-30
 */

#include <unitree/idl/go2/SportModeState_.hpp>
#include <unitree/robot/channel/channel_subscriber.hpp>
#include <ros/ros.h>
#include <sensor_msgs/Imu.h>
#include <geometry_msgs/PoseStamped.h>
#include <tf/transform_broadcaster.h>

#define TOPIC_HIGHSTATE "rt/sportmodestate"

using namespace unitree::robot;

ros::Publisher imu_pub;
ros::Publisher pose_pub;
tf::TransformBroadcaster* tf_broadcaster;

void HighStateHandler(const void* message)
{
    const auto& state = *(const unitree_go::msg::dds_::SportModeState_*)message;

    // 使用当前时间（或你可改为DDS时间戳）
    ros::Time stamp(
			state.stamp().sec(),
			state.stamp().nanosec()
			);

    // === 发布 IMU 消息 ===
    sensor_msgs::Imu imu_msg;
    imu_msg.header.stamp = stamp;
    imu_msg.header.frame_id = "imu_link";

    imu_msg.orientation.w = state.imu_state().quaternion()[0];
    imu_msg.orientation.x = state.imu_state().quaternion()[1];
    imu_msg.orientation.y = state.imu_state().quaternion()[2];
    imu_msg.orientation.z = state.imu_state().quaternion()[3];

    imu_msg.angular_velocity.x = state.imu_state().gyroscope()[0];
    imu_msg.angular_velocity.y = state.imu_state().gyroscope()[1];
    imu_msg.angular_velocity.z = state.imu_state().gyroscope()[2];

    imu_msg.linear_acceleration.x = state.imu_state().accelerometer()[0];
    imu_msg.linear_acceleration.y = state.imu_state().accelerometer()[1];
    imu_msg.linear_acceleration.z = state.imu_state().accelerometer()[2];

    for (int i = 0; i < 9; ++i)
    {
        imu_msg.orientation_covariance[i] = -1;
        imu_msg.angular_velocity_covariance[i] = -1;
        imu_msg.linear_acceleration_covariance[i] = -1;
    }

    imu_pub.publish(imu_msg);

    // === 发布 robot_pose 消息（map → base_link 的姿态） ===
    geometry_msgs::PoseStamped pose_msg;
    pose_msg.header.stamp = stamp;
    pose_msg.header.frame_id = "map";
    pose_msg.pose.position.x = state.position()[0];
    pose_msg.pose.position.y = state.position()[1];
    pose_msg.pose.position.z = state.position()[2];
    pose_msg.pose.orientation.w = state.imu_state().quaternion()[0];
    pose_msg.pose.orientation.x = state.imu_state().quaternion()[1];
    pose_msg.pose.orientation.y = state.imu_state().quaternion()[2];
    pose_msg.pose.orientation.z = state.imu_state().quaternion()[3];

    pose_pub.publish(pose_msg);

    // === 发布 TF: map → odom（替代使用robot_pose估计） ===
    tf::Transform map_to_odom;
    map_to_odom.setOrigin(tf::Vector3(
        state.position()[0],
        state.position()[1],
        state.position()[2]
    ));

    tf::Quaternion q(
        state.imu_state().quaternion()[1],  // x
        state.imu_state().quaternion()[2],  // y
        state.imu_state().quaternion()[3],  // z
        state.imu_state().quaternion()[0]   // w
    );
    map_to_odom.setRotation(q);

    tf_broadcaster->sendTransform(tf::StampedTransform(map_to_odom, stamp, "map", "base_link"));

    // === 调试输出 ===
    std::cout << "\n[INFO] Robot State:"
              << "\n  Position      = (" << pose_msg.pose.position.x << ", " << pose_msg.pose.position.y << ", " << pose_msg.pose.position.z << ")"
              << "\n  Orientation   = (" << imu_msg.orientation.w << ", " << imu_msg.orientation.x << ", "
              << imu_msg.orientation.y << ", " << imu_msg.orientation.z << ")"
              << "\n  Gyroscope     = (" << imu_msg.angular_velocity.x << ", "
              << imu_msg.angular_velocity.y << ", " << imu_msg.angular_velocity.z << ")"
              << "\n  Accelerometer = (" << imu_msg.linear_acceleration.x << ", "
              << imu_msg.linear_acceleration.y << ", " << imu_msg.linear_acceleration.z << ")"
              << "\n  RPY (Euler)   = (" << state.imu_state().rpy()[0] << ", "
              << state.imu_state().rpy()[1] << ", " << state.imu_state().rpy()[2] << ")"
              << "\n  TF: map -> base_link @ " << stamp.toSec()
              << std::endl;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "imu_tf_publisher");
    ros::NodeHandle nh;

    imu_pub = nh.advertise<sensor_msgs::Imu>("imu_data", 10);
    pose_pub = nh.advertise<geometry_msgs::PoseStamped>("robot_pose", 10);
    tf_broadcaster = new tf::TransformBroadcaster();

    std::string networkInterface = "eth0";  // 根据实际设置修改
    ChannelFactory::Instance()->Init(0, networkInterface);

    ChannelSubscriber<unitree_go::msg::dds_::SportModeState_> subscriber(TOPIC_HIGHSTATE);
    subscriber.InitChannel(HighStateHandler);

    ros::Rate rate(50);
    while (ros::ok())
    {
        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}
