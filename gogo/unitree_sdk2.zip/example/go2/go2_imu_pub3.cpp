/**
 * @file imu_state_tf_publisher.cpp
 * @brief Subscribe SportModeState from Unitree DDS and publish IMU + Position + TF as ROS1 messages
 * @date 2025-05-27
 */

#include <unitree/idl/go2/SportModeState_.hpp>
#include <unitree/robot/channel/channel_subscriber.hpp>
#include <ros/ros.h>
#include <sensor_msgs/Imu.h>
#include <geometry_msgs/PointStamped.h>
#include <tf/transform_broadcaster.h>

#define TOPIC_HIGHSTATE "rt/sportmodestate"

using namespace unitree::robot;

ros::Publisher imu_pub;
ros::Publisher position_pub;
tf::TransformBroadcaster *tf_broadcaster;

void HighStateHandler(const void* message)
{
    const auto& state = *(const unitree_go::msg::dds_::SportModeState_*)message;
    ros::Time now = ros::Time::now();

    // === 发布 IMU 消息 ===
    sensor_msgs::Imu imu_msg;
    imu_msg.header.stamp = now;
    imu_msg.header.frame_id = "imu_link";

    imu_msg.orientation.w = state.imu_state().quaternion()[0];
    imu_msg.orientation.x = state.imu_state().quaternion()[1];
    imu_msg.orientation.y = state.imu_state().quaternion()[2];
    imu_msg.orientation.z = state.imu_state().quaternion()[3];

    imu_msg.angular_velocity.x = state.imu_state().gyroscope()[0];
    imu_msg.angular_velocity.y = state.imu_state().gyroscope()[1];
    imu_msg.angular_velocity.z = state.imu_state().gyroscope()[2];

    imu_msg.linear_acceleration.x = state.imu_state().accelerometer()[0];
    imu_msg.linear_acceleration.y = state.imu_state().accelerometer()[1];
    imu_msg.linear_acceleration.z = state.imu_state().accelerometer()[2];

    // 协方差（默认填 -1 表示未知）
    for (int i = 0; i < 9; ++i)
    {
        imu_msg.orientation_covariance[i] = -1;
        imu_msg.angular_velocity_covariance[i] = -1;
        imu_msg.linear_acceleration_covariance[i] = -1;
    }

    imu_pub.publish(imu_msg);

    // === 发布位置消息 ===
    geometry_msgs::PointStamped pos_msg;
    pos_msg.header.stamp = now;
    pos_msg.header.frame_id = "map";
    pos_msg.point.x = state.position()[0];
    pos_msg.point.y = state.position()[1];
    pos_msg.point.z = state.position()[2];

    position_pub.publish(pos_msg);

    // === 发布 TF: map → base_link ===
    tf::Transform transform;
    transform.setOrigin(tf::Vector3(
        state.position()[0],
        state.position()[1],
        state.position()[2]
    ));
    tf::Quaternion q(
        state.imu_state().quaternion()[1],  // x
        state.imu_state().quaternion()[2],  // y
        state.imu_state().quaternion()[3],  // z
        state.imu_state().quaternion()[0]   // w
    );
    transform.setRotation(q);

    tf_broadcaster->sendTransform(tf::StampedTransform(transform, now, "map", "base_link"));

    // === 打印调试信息 ===
    std::cout << "\n[INFO] Robot State:"
              << "\n  Position      = (" << pos_msg.point.x << ", " << pos_msg.point.y << ", " << pos_msg.point.z << ")"
              << "\n  Orientation   = (" << imu_msg.orientation.w << ", " << imu_msg.orientation.x << ", "
              << imu_msg.orientation.y << ", " << imu_msg.orientation.z << ")"
              << "\n  Gyroscope     = (" << imu_msg.angular_velocity.x << ", "
              << imu_msg.angular_velocity.y << ", " << imu_msg.angular_velocity.z << ")"
              << "\n  Accelerometer = (" << imu_msg.linear_acceleration.x << ", "
              << imu_msg.linear_acceleration.y << ", " << imu_msg.linear_acceleration.z << ")"
              << "\n  RPY (Euler)   = (" << state.imu_state().rpy()[0] << ", "
              << state.imu_state().rpy()[1] << ", " << state.imu_state().rpy()[2] << ")"
              << std::endl;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "imu_tf_publisher");
    ros::NodeHandle nh;

    // 发布者
    imu_pub = nh.advertise<sensor_msgs::Imu>("imu_data", 10);
    position_pub = nh.advertise<geometry_msgs::PointStamped>("robot_position", 10);
    tf_broadcaster = new tf::TransformBroadcaster();  // 分配 TF 广播器

    // 初始化 DDS 通道
    std::string networkInterface = "eth0";  // 修改为实际网卡名
    ChannelFactory::Instance()->Init(0, networkInterface);

    ChannelSubscriber<unitree_go::msg::dds_::SportModeState_> subscriber(TOPIC_HIGHSTATE);
    subscriber.InitChannel(HighStateHandler);

    ros::Rate rate(50);  // 控制频率
    while (ros::ok())
    {
        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}
