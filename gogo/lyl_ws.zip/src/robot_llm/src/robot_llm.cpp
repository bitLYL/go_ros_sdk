#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <custom_msgs/MoveCommand.h>  // 假设 MoveCommand 是 llm 话题的数据类型
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <cmath>

class PosePrinter {
private:
    ros::NodeHandle nh_;
    ros::Subscriber pose_sub_;  // 订阅机器人位姿
    ros::Subscriber move_sub_;  // 订阅 llm 话题
    ros::Publisher target_pub_; // 发布目标点话题

    geometry_msgs::PoseStamped current_pose_;  // 用于存储机器人当前位置

public:
    PosePrinter() {
        // 订阅机器人位姿
        pose_sub_ = nh_.subscribe("/robot_pose", 10, &PosePrinter::poseCallback, this);

        // 订阅 llm 话题
        move_sub_ = nh_.subscribe("/llm", 10, &PosePrinter::moveCallback, this);

        // 发布目标位置话题
        target_pub_ = nh_.advertise<geometry_msgs::PoseStamped>("/target_pose", 10);

        ROS_INFO("Pose printer initialized");
    }

    // 机器人位姿回调函数
    void poseCallback(const geometry_msgs::PoseStamped::ConstPtr& msg) {
        // 更新当前机器人的位置
        current_pose_ = *msg;
    }

    // move话题回调函数
    void moveCallback(const custom_msgs::MoveCommand::ConstPtr& msg) {
        // 获取从 llm 话题接收到的数据
        double distance = msg->distance;
        double target_x = msg->x;  // 获取目标x坐标
        double target_y = msg->y;  // 获取目标y坐标

        // 如果 direction 是 std::vector<float>，取第一个值
        if (!msg->direction.empty()) {
            int direction = static_cast<int>(msg->direction[0]);  // 获取第一个方向值

            geometry_msgs::PoseStamped new_position = current_pose_;  // 起始位置为当前位置

            // 如果 direction 为 0，直接使用 x, y 作为目标点
            if (direction == 0) {
                new_position.pose.position.x = target_x;
                new_position.pose.position.y = target_y;
            } else {
                // 获取机器人当前朝向（四元数转欧拉角）
                tf2::Quaternion q(
                    current_pose_.pose.orientation.x,
                    current_pose_.pose.orientation.y,
                    current_pose_.pose.orientation.z,
                    current_pose_.pose.orientation.w
                );
                tf2::Matrix3x3 m(q);
                double roll, pitch, yaw;
                m.getRPY(roll, pitch, yaw);  // 获取机器人的朝向角度（yaw）

                // 根据 direction 来修改新的位置
                switch (direction) {
                    case 1:  // 前进
                        new_position.pose.position.x += distance * cos(yaw);
                        new_position.pose.position.y += distance * sin(yaw);
                        break;
                    case 2:  // 后退
                        new_position.pose.position.x -= distance * cos(yaw);
                        new_position.pose.position.y -= distance * sin(yaw);
                        break;
                    case 3:  // 向左
                        new_position.pose.position.x += distance * sin(yaw);
                        new_position.pose.position.y -= distance * cos(yaw);
                        break;
                    case 4:  // 向右
                        new_position.pose.position.x -= distance * sin(yaw);
                        new_position.pose.position.y += distance * cos(yaw);
                        break;
                    default:
                        ROS_WARN("Unknown direction: %d", direction);
                        return;
                }
            }

            // 打印新的目标位置
            ROS_INFO("Received Move Command:");
            ROS_INFO("Current Position: x=%.2f, y=%.2f", current_pose_.pose.position.x, current_pose_.pose.position.y);
            ROS_INFO("Target Position: x=%.2f, y=%.2f", new_position.pose.position.x, new_position.pose.position.y);

            // 发布目标位置
            publishTargetPosition(new_position);
        } else {
            ROS_WARN("Direction vector is empty");
        }
    }

    // 发布目标位置的消息
    void publishTargetPosition(const geometry_msgs::PoseStamped& target_pose) {
        target_pub_.publish(target_pose);
    }
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "pose_printer");
    PosePrinter printer;
    ros::spin();
    return 0;
}
