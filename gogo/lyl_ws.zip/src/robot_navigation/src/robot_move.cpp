#include <ros/ros.h>
#include <geometry_msgs/Twist.h>

class SimpleForwardMove {
private:
    ros::NodeHandle nh_;
    ros::Publisher cmd_vel_pub_;
    ros::Timer timer_;
    bool move_active_; // 是否在前进中

public:
    SimpleForwardMove() : move_active_(false) {
        // 创建cmd_vel发布者
        cmd_vel_pub_ = nh_.advertise<geometry_msgs::Twist>("/cmd_vel", 10);
        
        // 初始化定时器，3秒后调用停止
        timer_ = nh_.createTimer(ros::Duration(3.0), &SimpleForwardMove::stopMove, this, true); // 定时器只触发一次
        
        ROS_INFO("Simple forward move initialized");
    }

    // 发布前进指令
    void startMove() {
        geometry_msgs::Twist cmd_vel;
        cmd_vel.linear.x = 0.3; // 前进速度
        cmd_vel.angular.z = 0.0; // 角速度为零
        
        cmd_vel_pub_.publish(cmd_vel);
        move_active_ = true;

        ROS_INFO("Moving forward with speed 0.3 m/s");
    }

    // 停止前进
    void stopMove(const ros::TimerEvent&) {
        geometry_msgs::Twist cmd_vel;
        cmd_vel.linear.x = 0.0; // 停止前进
        cmd_vel.angular.z = 0.0; // 停止旋转
        
        cmd_vel_pub_.publish(cmd_vel);
        move_active_ = false;

        ROS_INFO("Movement stopped after 3 seconds");
    }
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "simple_forward_move");
    SimpleForwardMove forward_move;

    // 启动前进
    forward_move.startMove();
    
    // 进入ROS循环
    ros::spin();
    
    return 0;
}

