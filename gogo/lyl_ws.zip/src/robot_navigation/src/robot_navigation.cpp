#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Twist.h>
#include <nav_msgs/Path.h>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <cmath>
#include <vector>

class PathPlanningWithVisualization {
private:
    ros::NodeHandle nh_;
    ros::Subscriber pose_sub_;
    ros::Subscriber goal_sub_;
    ros::Publisher cmd_vel_pub_;
    ros::Publisher path_pub_;
    
    geometry_msgs::PoseStamped current_pose_;
    geometry_msgs::PoseStamped target_goal_;
    nav_msgs::Path planned_path_;
    bool goal_received_;
    bool path_generated_;
    
    // 控制器参数
    double linear_kp_;      // 线速度比例系数
    double angular_kp_;     // 角速度比例系数
    double linear_tolerance_;  // 位置容差
    double angular_tolerance_; // 角度容差
    double max_linear_speed_;  // 最大线速度
    double max_angular_speed_; // 最大角速度
    double path_point_interval_; // 路径点间隔(米)
    
public:
    PathPlanningWithVisualization() : nh_("~"), goal_received_(false), path_generated_(false) {
        // 订阅机器人当前位姿
        pose_sub_ = nh_.subscribe("/robot_pose", 10, &PathPlanningWithVisualization::poseCallback, this);
        
        // 订阅目标点
        //goal_sub_ = nh_.subscribe("/move_base_simple/goal", 10, &PathPlanningWithVisualization::goalCallback, this);
        goal_sub_ = nh_.subscribe("/target_pose", 10, &PathPlanningWithVisualization::goalCallback, this);
        
        // 发布速度指令和路径
        cmd_vel_pub_ = nh_.advertise<geometry_msgs::Twist>("/cmd_vel", 10);
        path_pub_ = nh_.advertise<nav_msgs::Path>("/planned_path", 10);
        
        // 初始化参数
        nh_.param("linear_kp", linear_kp_, 0.5);
        nh_.param("angular_kp", angular_kp_, 1.0);
        nh_.param("linear_tolerance", linear_tolerance_, 0.1);
        nh_.param("angular_tolerance", angular_tolerance_, 0.1);
        nh_.param("max_linear_speed", max_linear_speed_, 0.5);
        nh_.param("max_angular_speed", max_angular_speed_, 1.0);
        nh_.param("path_point_interval", path_point_interval_, 0.5); // 路径点间隔
        
        // 设置路径的坐标系
        planned_path_.header.frame_id = "map";
        
        ROS_INFO("Path Planning with Visualization initialized");
    }
    
    // 机器人位姿回调函数
    void poseCallback(const geometry_msgs::PoseStamped::ConstPtr& msg) {
        current_pose_ = *msg;
        
        // 更新路径中的当前位置
        updatePathWithCurrentPose();
        
        // 如果有目标点，进行路径规划
        if (goal_received_) {
            computeAndPublishVelocity();
        }
    }
    
    // 目标点回调函数
    void goalCallback(const geometry_msgs::PoseStamped::ConstPtr& msg) {
        target_goal_ = *msg;
        goal_received_ = true;
        path_generated_ = false;
        
        // 生成从当前位置到目标点的直线路径
        generateStraightLinePath();
        
        ROS_INFO("New goal received: (%.2f, %.2f)", 
                 target_goal_.pose.position.x, 
                 target_goal_.pose.position.y);
    }
    
    // 生成直线路径
    void generateStraightLinePath() {
        // 清空之前的路径
        planned_path_.poses.clear();
        
        // 计算目标点与当前位置的误差
        double dx = target_goal_.pose.position.x - current_pose_.pose.position.x;
        double dy = target_goal_.pose.position.y - current_pose_.pose.position.y;
        double distance = std::sqrt(dx * dx + dy * dy);
        
        // 如果距离太近，不需要生成路径
        if (distance < linear_tolerance_) {
            return;
        }
        
        // 计算路径点数量
        int point_count = static_cast<int>(distance / path_point_interval_) + 1;
        
        // 生成等距的路径点
        for (int i = 0; i <= point_count; i++) {
            geometry_msgs::PoseStamped path_point;
            path_point.header = planned_path_.header;
            path_point.header.stamp = ros::Time::now();
            
            // 线性插值计算路径点位置
            double t = static_cast<double>(i) / point_count;
            path_point.pose.position.x = current_pose_.pose.position.x + t * dx;
            path_point.pose.position.y = current_pose_.pose.position.y + t * dy;
            path_point.pose.position.z = 0.0; // 假设在2D平面上
            
            // 计算路径点的朝向（始终指向目标点）
            double target_angle = std::atan2(dy, dx);
            tf2::Quaternion q;
            q.setRPY(0, 0, target_angle);
            
            path_point.pose.orientation.x = q.x();
            path_point.pose.orientation.y = q.y();
            path_point.pose.orientation.z = q.z();
            path_point.pose.orientation.w = q.w();
            
            planned_path_.poses.push_back(path_point);
        }
        
        path_generated_ = true;
        ROS_INFO("Straight line path generated with %d points", point_count + 1);
    }
    
    // 更新路径中的当前位置
    void updatePathWithCurrentPose() {
        if (planned_path_.poses.empty()) {
            // 添加当前位置作为路径的起点
            geometry_msgs::PoseStamped current_pose_stamped = current_pose_;
            current_pose_stamped.header = planned_path_.header;
            planned_path_.poses.push_back(current_pose_stamped);
        } else {
            // 更新路径中的最后一个点为当前位置
            planned_path_.poses.back() = current_pose_;
        }
        
        // 更新路径的时间戳
        planned_path_.header.stamp = ros::Time::now();
        
        // 发布路径
        path_pub_.publish(planned_path_);
    }
    
    // 计算并发布速度指令
    void computeAndPublishVelocity() {
        // 计算目标点与当前位置的误差
        double dx = target_goal_.pose.position.x - current_pose_.pose.position.x;
        double dy = target_goal_.pose.position.y - current_pose_.pose.position.y;
        
        // 计算距离误差
        double distance_error = std::sqrt(dx * dx + dy * dy);
        
        // 如果到达目标点附近，停止运动
        if (distance_error < linear_tolerance_) {
            publishStopCommand();
            ROS_INFO("Goal reached!");
            goal_received_ = false;
            return;
        }
        
        // 计算目标角度（朝向目标点）
        double target_angle = std::atan2(dy, dx);
        
        // 获取当前机器人朝向（四元数转欧拉角）
        tf2::Quaternion q(
            current_pose_.pose.orientation.x,
            current_pose_.pose.orientation.y,
            current_pose_.pose.orientation.z,
            current_pose_.pose.orientation.w
        );
        tf2::Matrix3x3 m(q);
        double roll, pitch, yaw;
        m.getRPY(roll, pitch, yaw);
        double current_angle = yaw;
        
        // 计算角度误差（-pi 到 pi 之间）
        double angle_error = target_angle - current_angle;
        while (angle_error > M_PI) angle_error -= 2 * M_PI;
        while (angle_error < -M_PI) angle_error += 2 * M_PI;
        
        // 如果角度误差较大，先旋转
        if (std::abs(angle_error) > angular_tolerance_) {
            publishRotationCommand(angle_error);
            return;
        }
        
        // 角度误差较小，同时前进和微调
        publishMovementCommand(distance_error, angle_error);
    }
    
    // 发布旋转命令
    void publishRotationCommand(double angle_error) {
        geometry_msgs::Twist cmd_vel;
        
        // 计算角速度（比例控制）
        cmd_vel.angular.z = angular_kp_ * angle_error;
        
        // 限制最大角速度
        if (cmd_vel.angular.z > max_angular_speed_) {
            cmd_vel.angular.z = max_angular_speed_;
        } else if (cmd_vel.angular.z < -max_angular_speed_) {
            cmd_vel.angular.z = -max_angular_speed_;
        }
        
        // 发布速度指令
        cmd_vel_pub_.publish(cmd_vel);
    }
    
    // 发布前进命令
    void publishMovementCommand(double distance_error, double angle_error) {
        geometry_msgs::Twist cmd_vel;
        
        // 计算线速度（比例控制）
        cmd_vel.linear.x = linear_kp_ * distance_error;
        
        // 限制最大线速度
        if (cmd_vel.linear.x > max_linear_speed_) {
            cmd_vel.linear.x = max_linear_speed_;
        }
        
        // 微调角度
        cmd_vel.angular.z = angular_kp_ * angle_error;
        
        // 限制最大角速度
        if (cmd_vel.angular.z > max_angular_speed_) {
            cmd_vel.angular.z = max_angular_speed_;
        } else if (cmd_vel.angular.z < -max_angular_speed_) {
            cmd_vel.angular.z = -max_angular_speed_;
        }
        
        // 发布速度指令
        cmd_vel_pub_.publish(cmd_vel);
    }
    
    // 发布停止命令
    void publishStopCommand() {
        geometry_msgs::Twist cmd_vel;
        cmd_vel.linear.x = 0.0;
        cmd_vel.angular.z = 0.0;
        cmd_vel_pub_.publish(cmd_vel);
    }
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "path_planner_with_visualization");
    PathPlanningWithVisualization planner;
    ros::spin();
    return 0;
}

