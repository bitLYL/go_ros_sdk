#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Twist.h>
#include <tf2/LinearMath/Quaternion.h>
#include <cmath>
#include <unitree/robot/channel/channel_subscriber.hpp>
#include <unitree_go/msg/dds_/SportModeState_.hpp>

class MoveCommandHandler {
private:
    ros::NodeHandle nh_;
    ros::Subscriber move_sub_;
    ros::Publisher goal_pub_;
    
    geometry_msgs::PoseStamped current_pose_;
    unitree_go::msg::dds_::SportModeState_ state;
    bool goal_received_;
    
    float px0, py0, yaw0;  // 机器人初始位置和偏航角
    
public:
    MoveCommandHandler() : nh_("~"), goal_received_(false) {
        // 订阅move话题
        move_sub_ = nh_.subscribe("/move", 10, &MoveCommandHandler::moveCallback, this);
        
        // 发布目标点到RViz
        goal_pub_ = nh_.advertise<geometry_msgs::PoseStamped>("/move_base_simple/goal", 10);

        // 初始化Robot状态
        unitree::robot::ChannelFactory::Instance()->Init(0, "eth0");  // 假设网络接口为eth0
        unitree::robot::ChannelSubscriber<unitree_go::msg::dds_::SportModeState_> suber("rt/sportmodestate");
        suber.InitChannel(std::bind(&MoveCommandHandler::HighStateHandler, this, std::placeholders::_1), 1);
        
        ROS_INFO("Move command handler initialized");
    }
    
    // 高层数据接收的回调函数
    void HighStateHandler(const void *message) {
        state = *(unitree_go::msg::dds_::SportModeState_ *)message;
        px0 = state.position()[0];
        py0 = state.position()[1];
        yaw0 = state.imu_state().rpy()[2];
        ROS_INFO("Initial position: x0: %.2f, y0: %.2f, yaw0: %.2f", px0, py0, yaw0);
    }
    
    // move话题回调函数
    void moveCallback(const geometry_msgs::Twist::ConstPtr& msg) {
        // 方向（direction）和距离（distance）从move消息获取
        int direction = static_cast<int>(msg->angular.z);  // 假设direction由angular.z传递
        float distance = msg->linear.x;  // 假设distance由linear.x传递
        
        // 获取当前机器人的位姿
        getCurrentPose();

        // 目标点
        geometry_msgs::PoseStamped target_goal;

        // 目标位置计算
        if (direction == 0) {
            // 如果direction为0，直接发布当前位置作为目标
            target_goal = current_pose_;
            ROS_INFO("Goal is set to current position");
        } else {
            // 根据direction计算目标位置
            target_goal = calculateGoalPosition(direction, distance);
            ROS_INFO("Goal is set with direction: %d, distance: %.2f", direction, distance);
        }

        // 发布目标
        goal_pub_.publish(target_goal);
    }
    
    // 获取当前机器人位姿
    void getCurrentPose() {
        current_pose_.pose.position.x = px0;
        current_pose_.pose.position.y = py0;
        current_pose_.pose.position.z = 0.0;
        
        tf2::Quaternion q;
        q.setRPY(0, 0, yaw0);
        
        current_pose_.pose.orientation.x = q.x();
        current_pose_.pose.orientation.y = q.y();
        current_pose_.pose.orientation.z = q.z();
        current_pose_.pose.orientation.w = q.w();
    }
    
    // 根据方向和距离计算目标位置
    geometry_msgs::PoseStamped calculateGoalPosition(int direction, float distance) {
        geometry_msgs::PoseStamped goal;
        
        // 计算目标点的坐标
        double dx = 0.0;
        double dy = 0.0;
        double target_angle = 0.0;
        
        switch (direction) {
            case 1:  // 前进
                dx = distance;
                dy = 0.0;
                target_angle = 0.0;
                break;
            case 2:  // 后退
                dx = -distance;
                dy = 0.0;
                target_angle = M_PI;  // 180度
                break;
            case 3:  // 向左
                dx = 0.0;
                dy = distance;
                target_angle = M_PI_2;  // 90度
                break;
            case 4:  // 向右
                dx = 0.0;
                dy = -distance;
                target_angle = -M_PI_2;  // -90度
                break;
            case 5:  // 左前
                dx = distance * cos(M_PI_4);
                dy = distance * sin(M_PI_4);
                target_angle = M_PI_4;  // 45度
                break;
            case 6:  // 右前
                dx = distance * cos(-M_PI_4);
                dy = distance * sin(-M_PI_4);
                target_angle = -M_PI_4;  // -45度
                break;
            default:
                ROS_WARN("Unknown direction: %d", direction);
                return goal;
        }

        // 计算目标位置
        goal.pose.position.x = px0 + dx;
        goal.pose.position.y = py0 + dy;
        goal.pose.position.z = 0.0;  // 假设在2D平面上

        // 设置目标角度
        tf2::Quaternion q;
        q.setRPY(0, 0, target_angle);
        goal.pose.orientation.x = q.x();
        goal.pose.orientation.y = q.y();
        goal.pose.orientation.z = q.z();
        goal.pose.orientation.w = q.w();

        return goal;
    }
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "move_command_handler");
    MoveCommandHandler handler;
    ros::spin();
    return 0;
}

