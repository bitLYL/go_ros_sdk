#include <ros/ros.h>
#include <geometry_msgs/Twist.h>

int main(int argc, char **argv)
{
    ros::init(argc, argv, "cmd_vel_once");
    ros::NodeHandle nh;

    ros::Publisher cmd_pub = nh.advertise<geometry_msgs::Twist>("/cmd_vel", 10);

    // 等待发布器连接到订阅者
    ros::Duration(0.5).sleep();

    geometry_msgs::Twist move_cmd;
    move_cmd.linear.x = 0.3;
    move_cmd.angular.z = 0.0;

    ROS_INFO("Publishing forward velocity...");
    cmd_pub.publish(move_cmd);

    // 保持 1 秒
    ros::Duration(3.0).sleep();

    // 清零速度
    move_cmd.linear.x = 0.0;
    cmd_pub.publish(move_cmd);
    ROS_INFO("Velocity cleared.");

    return 0;
}

